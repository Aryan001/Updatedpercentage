    array = [];
    function Remove(event)
    {
        console.log(event.currentTarget.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.attributes.id.value);
        array.push(event.currentTarget.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.attributes.id.value);
        var el = document.querySelector("#" + event.currentTarget.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.attributes.id.value);
        console.log(el);
        angular.element(el).addClass('remove')
        if (document.getElementById('forbutton').innerHTML == '') {
            createButton();
        }
        document.getElementById('forbutton').style.visibility = 'visible';
    }

    var a = [];//, i;
    function Resize(event, i)
    {
        var optionsIndex = event.currentTarget.attributes.id.value;
        optionsIndex = optionsIndex.substr(6, optionsIndex.length - 6);
        var divId = 'div' + optionsIndex.toString();
        var divOuterId = 'divOuter' + optionsIndex.toString();

        var shrinkOrExpand = 0;
        if (a[i] == 0)
        {
            a[i] = 1;
            shrinkOrExpand = 1;
            console.log(event.currentTarget.attributes.id.value);
            document.getElementById(event.currentTarget.attributes.id.value).className = "glyphicon glyphicon-resize-small";
            document.getElementById(divOuterId).style.width="93%";
        }
        else
        {
            a[i] = 0;
            shrinkOrExpand = 0;
            document.getElementById(event.currentTarget.attributes.id.value).className = "glyphicon glyphicon-resize-full";
            document.getElementById(divOuterId).style.width ="45%";
        }
        ResizeChart(optionsIndex, shrinkOrExpand);
    }


    function SetVisibility()
    {
        console.log("hai");

        var a = document.querySelectorAll(".draggable2");
        for (var k = 0; k < a.length; k++)
        {
            angular.element(a[k]).removeClass('remove');

        }
        document.getElementById('forbutton').style.visibility = 'hidden';
    }

    function Home()
    {
        array = [];
        var a = document.querySelectorAll(".draggable");
        console.log(a);
        a.class = '';
    }

    function Onegraph(event)
    {
      console.log('hai1');
      var myEl = angular.element(document.querySelectorAll('.draggable2'));
      for(i=0;i<myEl.length;i++)
      {
        myEl.css('width','93%');
        // grp.setAttribute('width','1330px');
      }
    }

    function Twograph()
    {
       console.log('hai2');
       var myEl = angular.element(document.querySelectorAll('.draggable2'));
       for(i=0;i<myEl.length;i++)
       {
         myEl.css('width','45%');
       }
    }

    function Threegraph()
    {
      console.log('hai3');
      var myEl = angular.element(document.querySelectorAll('.draggable2'));
      for(i=0;i<myEl.length;i++)
      {
        myEl.css('width','30%');
      }
    }


    function fourGraph()
    {
      console.log('hai3');
      var myEl = angular.element(document.querySelectorAll('.draggable2'));
      for(i=0;i<myEl.length;i++)
      {
        myEl.css('width','22%');
      }
    }


    var j = -1;
    function AddDiv(inEntireRow,width,height)
    {
        j++;
        var divId = 'div' + j.toString();
        var resizeId = 'resize' + j.toString();
        // console.log('resize is ' + resizeId);
        var divOuterId = 'divOuter' + j.toString();
        // console.log(j);
        // console.log(divId);

        var innerHTML =       '<div class="draggable2" class="ui-widget-content" flex="50" id="' + divOuterId + '">';
        innerHTML=innerHTML + '<div layout="row" flex id="divhead">';
        innerHTML = innerHTML + '<table width="100%;" border="0">';
        innerHTML = innerHTML + '<tr><td align="right" width="75%">';
        innerHTML=innerHTML + '<span flex="5" class="glyphicon glyphicon-resize-full"  id="'+resizeId+'" onclick="javascript:Resize(event, ' + j + ')">';
        innerHTML = innerHTML + '</span>';
        innerHTML = innerHTML + '</td><td align="middle" width="15%">';
        innerHTML=innerHTML + '<span flex="5" class="glyphicon glyphicon-remove-circle" id="close" onclick="javascript:Remove(event)">';
        innerHTML = innerHTML + '</span>';
        innerHTML = innerHTML + '</td><td width="10%"></td></tr>';
        innerHTML = innerHTML + '<tr><td colspan="2">';
        innerHTML = innerHTML + '<div style="width:100%;position:relative;left:0px;" id="' + divId + '">';
        innerHTML = innerHTML + '</div>';
        innerHTML = innerHTML + '</td></tr></table>';
        innerHTML=innerHTML + '</div>';
        innerHTML=innerHTML + '</div>';

        var firstDiv = document.getElementById('FirstDiv');
        firstDiv.innerHTML = firstDiv.innerHTML + innerHTML;

        var divOuterId = 'divOuter' + j.toString();
        if (inEntireRow == 1)
        {
            document.getElementById(divOuterId).style.width = "93%";
            document.getElementById(resizeId).style.visibility='hidden';
        }
        else {
          if(width>50)
          {
            document.getElementById(divOuterId).style.width = width +'%';
            document.getElementById(divOuterId).style.height= height +'%';
            document.getElementById(resizeId).style.visibility='hidden';
          }
          else {
            document.getElementById(divOuterId).style.width = width +'%';
            document.getElementById(divOuterId).style.height= height +'%';
          }

        }
        a.push(0);

        return divId;
    }


    function createButton()
    {
      var btn = document.createElement("BUTTON");
      var target = document.createTextNode("Show All");
      document.getElementById('forbutton').appendChild(btn);
      btn.appendChild(target);
      btn.onclick=SetVisibility;
    }

    function dropdown()
    {
        var innerHTML=  '<button class="dropdown"data-toggle="dropdown">Dropdown';
        innerHTML=innerHTML + '<ul class="dropdown-menu">';
        innerHTML=innerHTML + '<li><a href="#" onclick="javascript:Onegraph(event)">One Graph</a></li>';
        innerHTML=innerHTML + '<li><a href="#" onclick="javascript:Twograph(event)">Two Graph</a></li>';
        innerHTML=innerHTML + '<li><a href="#" onclick="javascript:Threegraph(event)">Three Graph</a></li>';
        innerHTML=innerHTML + '<li><a href="#" onclick="javascript:fourGraph(event)">Four Graphs</a></li>';
        innerHTML=innerHTML + '</ul>';
        innerHTML=innerHTML + '</button>';

        var secDiv = document.getElementById('goog');
        secDiv.innerHTML = secDiv.innerHTML + innerHTML;

        $('button.dropdown').hover(function() {
          $(this).find('.dropdown-menu').stop(true, true).delay(200).fadeIn(500);
        }, function() {
          $(this).find('.dropdown-menu').stop(true, true).delay(200).fadeOut(500);
        });

    }


  $(function()
  {
    $('.dynamic').sortable();
    $( '.dynamic').disableSelection();
  })
